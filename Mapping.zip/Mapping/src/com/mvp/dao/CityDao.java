package com.mvp.dao;

import com.mvp.model.City;
import java.util.List;

public interface CityDao {
	
	public List<City> getAllCity();

}
