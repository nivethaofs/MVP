package com.mvp.dao;

import com.mvp.model.Hotel;
import java.util.List;

public interface HotelDao {
	
	public List<Hotel> getAllHotel();
	
}
