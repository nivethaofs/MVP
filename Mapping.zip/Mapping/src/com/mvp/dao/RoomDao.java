package com.mvp.dao;

import com.mvp.model.Room;
import java.util.List;

public interface RoomDao {
	
	public List<Room> getAllRoom();

}
