
package com.mvp.service;

import java.util.List;
import com.mvp.model.City;

public interface CityService {

	public List<City> getAllCities();
	
}
