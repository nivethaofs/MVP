package com.mvp.service;

import java.util.List;
import com.mvp.model.Room;

public interface RoomService {

	public List<Room> getAllRooms();

}
