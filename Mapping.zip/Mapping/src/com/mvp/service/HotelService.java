package com.mvp.service;

import java.util.List;
import com.mvp.model.Hotel;

public interface HotelService {

	public List<Hotel> getAllHotels();

}
